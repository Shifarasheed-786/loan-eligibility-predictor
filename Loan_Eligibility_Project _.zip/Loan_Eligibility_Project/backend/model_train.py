import pandas as pd
import numpy as np
import pickle
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import warnings
warnings.filterwarnings('ignore')
def load_data(filepath=r"C:\Users\TARA\Downloads\loan_dataset.csv"):

    """Load the loan dataset"""
    print("📂 Loading dataset...")
    df = pd.read_csv(filepath)
    print(f"✓ Dataset loaded: {df.shape[0]} rows, {df.shape[1]} columns\n")
    return df

def preprocess_data(df):
    """Preprocess and clean the dataset"""
    print("🔧 Preprocessing data...")
    
    # Make a copy
    df = df.copy()
    
    # Drop Loan_ID as it's not a feature
    if 'Loan_ID' in df.columns:
        df = df.drop('Loan_ID', axis=1)
    
    # Handle missing values
    print("  → Handling missing values...")
    
    # Fill numerical missing values with median
    numerical_cols = ['LoanAmount', 'Loan_Amount_Term', 'Credit_History']
    for col in numerical_cols:
        if col in df.columns:
            df[col].fillna(df[col].median(), inplace=True)
    
    # Fill categorical missing values with mode
    categorical_cols = ['Gender', 'Married', 'Dependents', 'Self_Employed']
    for col in categorical_cols:
        if col in df.columns:
            df[col].fillna(df[col].mode()[0], inplace=True)
    
    # Handle Dependents column (3+ → 3)
    if 'Dependents' in df.columns:
        df['Dependents'] = df['Dependents'].replace('3+', '3').astype(int)
    
    # Encode categorical variables
    print("  → Encoding categorical variables...")
    le_dict = {}
    categorical_features = ['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area']
    
    for col in categorical_features:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col])
            le_dict[col] = le
    
    # Feature Engineering
    print("  → Engineering new features...")
    
    # Total Income
    df['Total_Income'] = df['ApplicantIncome'] + df['CoapplicantIncome']
    
    # Income to Loan Ratio
    df['Income_Loan_Ratio'] = df['Total_Income'] / df['LoanAmount']
    
    # Loan Amount per Term
    df['Loan_Amount_Term_Ratio'] = df['LoanAmount'] / df['Loan_Amount_Term']
    
    print("✓ Preprocessing complete\n")
    
    return df, le_dict

def train_model(X_train, y_train):
    """Train the Random Forest model"""
    print("🤖 Training Random Forest model...")
    
    # Initialize model with optimized parameters
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=10,
        min_samples_leaf=4,
        random_state=42,
        n_jobs=-1
    )
    
    # Train the model
    model.fit(X_train, y_train)
    
    print("✓ Model training complete\n")
    
    return model

def evaluate_model(model, X_train, X_test, y_train, y_test):
    """Evaluate model performance"""
    print("📊 Evaluating model performance...\n")
    
    # Training accuracy
    train_pred = model.predict(X_train)
    train_accuracy = accuracy_score(y_train, train_pred)
    print(f"Training Accuracy: {train_accuracy:.4f} ({train_accuracy*100:.2f}%)")
    
    # Testing accuracy
    test_pred = model.predict(X_test)
    test_accuracy = accuracy_score(y_test, test_pred)
    print(f"Testing Accuracy:  {test_accuracy:.4f} ({test_accuracy*100:.2f}%)")
    
    # Cross-validation score
    cv_scores = cross_val_score(model, X_train, y_train, cv=5)
    print(f"Cross-Val Accuracy: {cv_scores.mean():.4f} (±{cv_scores.std():.4f})")
    
    # Classification Report
    print("\n" + "="*60)
    print("CLASSIFICATION REPORT")
    print("="*60)
    print(classification_report(y_test, test_pred, 
                                target_names=['Rejected', 'Approved'],
                                digits=4))
    
    # Confusion Matrix
    cm = confusion_matrix(y_test, test_pred)
    print("CONFUSION MATRIX")
    print("="*60)
    print(f"                Predicted Rejected  Predicted Approved")
    print(f"Actual Rejected      {cm[0][0]:6d}              {cm[0][1]:6d}")
    print(f"Actual Approved      {cm[1][0]:6d}              {cm[1][1]:6d}")
    print("="*60 + "\n")
    
    # Feature Importance
    print("TOP 10 FEATURE IMPORTANCES")
    print("="*60)
    feature_names = X_train.columns
    importances = model.feature_importances_
    indices = np.argsort(importances)[::-1][:10]
    
    for i, idx in enumerate(indices, 1):
        print(f"{i:2d}. {feature_names[idx]:25s} {importances[idx]:.4f} ({importances[idx]*100:.2f}%)")
    print("="*60 + "\n")

def save_model(model, filepath='loan_model.pkl'):
    """Save the trained model"""
    print(f"💾 Saving model to {filepath}...")
    with open(filepath, 'wb') as f:
        pickle.dump(model, f)
    print("✓ Model saved successfully\n")

def main():
    """Main training pipeline"""
    
    print("\n" + "="*60)
    print("       LOAN ELIGIBILITY PREDICTION - MODEL TRAINING")
    print("="*60 + "\n")
    
    # Load data
    df = load_data()
    
    # Display dataset info
    print("DATASET OVERVIEW")
    print("="*60)
    print(f"Total samples: {len(df)}")
    print(f"Features: {len(df.columns) - 1}")  # -1 for target
    if 'Loan_Status' in df.columns:
        print(f"Approved loans: {(df['Loan_Status'] == 'Y').sum()}")
        print(f"Rejected loans: {(df['Loan_Status'] == 'N').sum()}")
    print("="*60 + "\n")
    
    # Preprocess data
    df_processed, le_dict = preprocess_data(df)
    
    # Encode target variable
    if 'Loan_Status' in df_processed.columns:
        le_target = LabelEncoder()
        df_processed['Loan_Status'] = le_target.fit_transform(df_processed['Loan_Status'])
    
    # Split features and target
    X = df_processed.drop('Loan_Status', axis=1)
    y = df_processed['Loan_Status']
    
    # Train-test split
    print("📊 Splitting dataset (80% train, 20% test)...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"✓ Training set: {len(X_train)} samples")
    print(f"✓ Testing set:  {len(X_test)} samples\n")
    
    # Train model
    model = train_model(X_train, y_train)
    
    # Evaluate model
    evaluate_model(model, X_train, X_test, y_train, y_test)
    
    # Save model
    save_model(model)
    
    print("="*60)
    print("✓ TRAINING COMPLETE!")
    print("="*60)
    print("Next steps:")
    print("1. Start the backend server: python backend/app.py")
    print("2. Open frontend/index.html in your browser")
    print("3. Start making predictions!")
    print("="*60 + "\n")

if __name__ == '__main__':
    main()
