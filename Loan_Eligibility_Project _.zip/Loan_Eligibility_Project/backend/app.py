from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

# Load the trained model
MODEL_PATH = 'loan_model.pkl'

# Global variables
model = None
label_encoders = {}

def load_model():
    """Load the trained model"""
    global model
    if os.path.exists(MODEL_PATH):
        with open(MODEL_PATH, 'rb') as f:
            model = pickle.load(f)
        print(f"✓ Model loaded successfully from {MODEL_PATH}")
    else:
        print(f"⚠ Model file not found at {MODEL_PATH}")
        print("  Please train the model first using model_train.py")

def preprocess_input(data):
    """Preprocess input data for prediction"""
    
    # Create a DataFrame from input
    df = pd.DataFrame([data])
    
    # Handle categorical encoding
    categorical_columns = ['Gender', 'Married', 'Education', 'Self_Employed', 'Property_Area']
    
    for col in categorical_columns:
        if col in df.columns:
            le = LabelEncoder()
            # Fit on common values
            if col == 'Gender':
                le.fit(['Male', 'Female'])
            elif col in ['Married', 'Self_Employed']:
                le.fit(['Yes', 'No'])
            elif col == 'Education':
                le.fit(['Graduate', 'Not Graduate'])
            elif col == 'Property_Area':
                le.fit(['Urban', 'Semiurban', 'Rural'])
            
            df[col] = le.transform(df[col])
    
    # Handle Dependents
    if 'Dependents' in df.columns:
        df['Dependents'] = df['Dependents'].replace('3+', '3').astype(int)
    
    # Feature Engineering (same as training)
    df['Total_Income'] = df['ApplicantIncome'] + df['CoapplicantIncome']
    df['Income_Loan_Ratio'] = df['Total_Income'] / df['LoanAmount']
    df['Loan_Amount_Term_Ratio'] = df['LoanAmount'] / df['Loan_Amount_Term']
    
    # Define feature order (must match training)
    feature_columns = [
        'Gender', 'Married', 'Dependents', 'Education', 'Self_Employed',
        'ApplicantIncome', 'CoapplicantIncome', 'LoanAmount',
        'Loan_Amount_Term', 'Credit_History', 'Property_Area',
        'Total_Income', 'Income_Loan_Ratio', 'Loan_Amount_Term_Ratio'
    ]
    
    # Ensure all features are present
    for col in feature_columns:
        if col not in df.columns:
            df[col] = 0
    
    return df[feature_columns]

@app.route('/')
def home():
    """Home route"""
    return jsonify({
        'message': 'LoanIQ API - Loan Eligibility Prediction Service',
        'version': '1.0',
        'status': 'running',
        'model_loaded': model is not None,
        'endpoints': {
            '/predict': 'POST - Make a prediction',
            '/health': 'GET - Check API health'
        }
    })

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': model is not None
    })

@app.route('/predict', methods=['POST'])
def predict():
    """Prediction endpoint"""
    
    if model is None:
        return jsonify({
            'error': 'Model not loaded',
            'message': 'Please train the model first using model_train.py'
        }), 500
    
    try:
        # Get JSON data from request
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Preprocess input
        processed_data = preprocess_input(data)
        
        # Make prediction
        prediction = model.predict(processed_data)
        prediction_proba = model.predict_proba(processed_data)
        
        # Get confidence score
        confidence = float(prediction_proba[0][prediction[0]] * 100)
        
        # Prepare response
        result = {
            'prediction': 'Approved' if prediction[0] == 1 else 'Rejected',
            'confidence': round(confidence, 2),
            'probability': {
                'approved': round(float(prediction_proba[0][1] * 100), 2),
                'rejected': round(float(prediction_proba[0][0] * 100), 2)
            }
        }
        
        return jsonify(result)
    
    except Exception as e:
        print(f"Error during prediction: {str(e)}")
        return jsonify({
            'error': 'Prediction failed',
            'message': str(e)
        }), 500

if __name__ == '__main__':
    load_model()
    print("\n" + "="*50)
    print("🚀 LoanIQ Backend API Starting...")
    print("="*50)
    print(f"📍 Server running on: http://localhost:5000")
    print(f"📊 Model status: {'Loaded ✓' if model else 'Not Loaded ✗'}")
    print("="*50 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
