# Dataset Information

## Quick Download Link

Download the Loan Prediction Dataset from Kaggle:
https://www.kaggle.com/datasets/altruistdelhite04/loan-prediction-problem-dataset

## Alternative: Create Sample Data

If you want to create a small sample dataset for testing, here's the structure:

### Required Columns:
- Loan_ID (e.g., LP001002)
- Gender (Male/Female)
- Married (Yes/No)
- Dependents (0/1/2/3+)
- Education (Graduate/Not Graduate)
- Self_Employed (Yes/No)
- ApplicantIncome (numerical)
- CoapplicantIncome (numerical)
- LoanAmount (numerical, in thousands)
- Loan_Amount_Term (numerical, in months - typically 360, 180, 120)
- Credit_History (1.0 for good, 0.0 for bad)
- Property_Area (Urban/Semiurban/Rural)
- Loan_Status (Y for approved, N for rejected) - TARGET VARIABLE

### Sample CSV Format:

```csv
Loan_ID,Gender,Married,Dependents,Education,Self_Employed,ApplicantIncome,CoapplicantIncome,LoanAmount,Loan_Amount_Term,Credit_History,Property_Area,Loan_Status
LP001002,Male,No,0,Graduate,No,5849,0,128,360,1,Urban,Y
LP001003,Male,Yes,1,Graduate,No,4583,1508,128,360,1,Rural,N
LP001005,Male,Yes,0,Graduate,Yes,3000,0,66,360,1,Urban,Y
LP001006,Male,Yes,2,Graduate,No,2583,2358,120,360,1,Urban,Y
LP001008,Male,No,0,Not Graduate,No,6000,0,141,360,1,Urban,Y
```

## After Downloading:

1. Save the file as `loan_data.csv`
2. Place it in the `dataset/` folder
3. Run `python backend/model_train.py` to train the model
4. The model will be saved as `backend/loan_model.pkl`

## Dataset Statistics (typical):

- Total Records: 600-650
- Features: 12
- Target: Loan_Status (Binary: Y/N)
- Approved Loans: ~70%
- Rejected Loans: ~30%

## Common Issues:

1. **Missing Values**: The model handles this automatically
2. **Encoding**: Categorical variables are auto-encoded
3. **Feature Engineering**: Done automatically during training
