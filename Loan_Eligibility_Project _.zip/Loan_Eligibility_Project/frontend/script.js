// ============================================
// LoanIQ - Application Logic
// ============================================

// Configuration
const CONFIG = {
    API_URL: 'http://localhost:5000/predict',
    ANIMATION_DELAY: 300
};

// DOM Elements
const loanForm = document.getElementById('loanForm');
const submitBtn = document.getElementById('submitBtn');
const resultsPlaceholder = document.getElementById('resultsPlaceholder');
const resultsContent = document.getElementById('resultsContent');
const resultIcon = document.getElementById('resultIcon');
const resultStatus = document.getElementById('resultStatus');
const confidenceValue = document.getElementById('confidenceValue');
const factorsList = document.getElementById('factorsList');
const summaryGrid = document.getElementById('summaryGrid');
const resetBtn = document.getElementById('resetBtn');
const downloadBtn = document.getElementById('downloadBtn');

// State
let currentPrediction = null;

// ============================================
// Form Submission Handler
// ============================================

loanForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Get form data
    const formData = new FormData(loanForm);
    const data = {
        Gender: formData.get('gender'),
        Married: formData.get('married'),
        Dependents: formData.get('dependents'),
        Education: formData.get('education'),
        Self_Employed: formData.get('selfEmployed'),
        ApplicantIncome: parseFloat(formData.get('applicantIncome')),
        CoapplicantIncome: parseFloat(formData.get('coapplicantIncome')),
        LoanAmount: parseFloat(formData.get('loanAmount')),
        Loan_Amount_Term: parseFloat(formData.get('loanTerm')),
        Credit_History: parseFloat(formData.get('creditHistory')),
        Property_Area: formData.get('propertyArea')
    };
    
    // Show loading state
    setLoadingState(true);
    
    try {
        // Make API call
        const response = await fetch(CONFIG.API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error('Prediction failed');
        }
        
        const result = await response.json();
        currentPrediction = { ...result, formData: data };
        
        // Display results
        displayResults(result, data);
        
    } catch (error) {
        console.error('Error:', error);
        showError();
    } finally {
        setLoadingState(false);
    }
});

// ============================================
// Display Results
// ============================================

function displayResults(result, formData) {
    // Hide placeholder, show results
    resultsPlaceholder.style.display = 'none';
    resultsContent.style.display = 'flex';
    
    // Scroll to results on mobile
    if (window.innerWidth <= 1024) {
        resultsContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    
    const isApproved = result.prediction === 'Approved';
    const confidence = result.confidence || calculateConfidence(result.prediction, formData);
    
    // Update result card
    resultIcon.className = `result-icon ${isApproved ? 'approved' : 'rejected'}`;
    resultStatus.textContent = result.prediction;
    resultStatus.className = `result-status ${isApproved ? 'approved' : 'rejected'}`;
    confidenceValue.textContent = `${confidence.toFixed(1)}%`;
    
    // Display factors
    displayFactors(formData, isApproved);
    
    // Display summary
    displaySummary(formData);
}

// ============================================
// Display Key Factors
// ============================================

function displayFactors(data, isApproved) {
    const factors = analyzeFactors(data, isApproved);
    
    factorsList.innerHTML = factors.map(factor => `
        <div class="factor-item">
            <span class="factor-icon">${factor.icon}</span>
            <span class="factor-text">${factor.text}</span>
            <span class="factor-impact ${factor.impact}">${factor.value}</span>
        </div>
    `).join('');
}

function analyzeFactors(data, isApproved) {
    const factors = [];
    
    // Credit History (most important)
    if (data.Credit_History === 1) {
        factors.push({
            icon: '✓',
            text: 'Excellent credit history',
            value: '+60%',
            impact: 'positive'
        });
    } else {
        factors.push({
            icon: '✗',
            text: 'Poor credit history',
            value: '-60%',
            impact: 'negative'
        });
    }
    
    // Income to Loan Ratio
    const totalIncome = data.ApplicantIncome + data.CoapplicantIncome;
    const incomeRatio = totalIncome / data.LoanAmount;
    
    if (incomeRatio > 0.4) {
        factors.push({
            icon: '📈',
            text: 'Strong income-to-loan ratio',
            value: '+18%',
            impact: 'positive'
        });
    } else if (incomeRatio < 0.2) {
        factors.push({
            icon: '📉',
            text: 'Low income-to-loan ratio',
            value: '-15%',
            impact: 'negative'
        });
    } else {
        factors.push({
            icon: '➡️',
            text: 'Moderate income-to-loan ratio',
            value: '±0%',
            impact: ''
        });
    }
    
    // Education
    if (data.Education === 'Graduate') {
        factors.push({
            icon: '🎓',
            text: 'Graduate education level',
            value: '+4%',
            impact: 'positive'
        });
    }
    
    // Property Area
    if (data.Property_Area === 'Semiurban') {
        factors.push({
            icon: '🏘️',
            text: 'Semi-urban property location',
            value: '+3%',
            impact: 'positive'
        });
    } else if (data.Property_Area === 'Urban') {
        factors.push({
            icon: '🏙️',
            text: 'Urban property location',
            value: '+2%',
            impact: 'positive'
        });
    }
    
    // Employment
    if (data.Self_Employed === 'No') {
        factors.push({
            icon: '💼',
            text: 'Salaried employment',
            value: '+2%',
            impact: 'positive'
        });
    }
    
    return factors;
}

// ============================================
// Display Summary
// ============================================

function displaySummary(data) {
    const totalIncome = data.ApplicantIncome + data.CoapplicantIncome;
    const emi = calculateEMI(data.LoanAmount, data.Loan_Amount_Term);
    const emiRatio = (emi / totalIncome * 100).toFixed(1);
    
    summaryGrid.innerHTML = `
        <div class="summary-item">
            <div class="summary-label">Total Monthly Income</div>
            <div class="summary-value">₹${totalIncome.toLocaleString('en-IN')}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Loan Amount</div>
            <div class="summary-value">₹${data.LoanAmount.toLocaleString('en-IN')}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Estimated EMI</div>
            <div class="summary-value">₹${emi.toLocaleString('en-IN')}</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">EMI to Income Ratio</div>
            <div class="summary-value">${emiRatio}%</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Loan Term</div>
            <div class="summary-value">${data.Loan_Amount_Term} months</div>
        </div>
        <div class="summary-item">
            <div class="summary-label">Property Area</div>
            <div class="summary-value">${data.Property_Area}</div>
        </div>
    `;
}

// ============================================
// Utility Functions
// ============================================

function calculateEMI(principal, months, annualRate = 10) {
    const monthlyRate = annualRate / 12 / 100;
    const emi = principal * monthlyRate * Math.pow(1 + monthlyRate, months) / 
                (Math.pow(1 + monthlyRate, months) - 1);
    return Math.round(emi);
}

function calculateConfidence(prediction, data) {
    // Simple confidence calculation based on key factors
    let confidence = 50;
    
    if (data.Credit_History === 1) {
        confidence += 25;
    } else {
        confidence -= 25;
    }
    
    const totalIncome = data.ApplicantIncome + data.CoapplicantIncome;
    const incomeRatio = totalIncome / data.LoanAmount;
    
    if (incomeRatio > 0.4) {
        confidence += 15;
    } else if (incomeRatio < 0.2) {
        confidence -= 15;
    }
    
    if (data.Education === 'Graduate') {
        confidence += 5;
    }
    
    if (data.Property_Area === 'Semiurban') {
        confidence += 3;
    }
    
    if (prediction === 'Rejected') {
        confidence = 100 - confidence;
    }
    
    return Math.max(55, Math.min(95, confidence));
}

function setLoadingState(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtn.classList.toggle('loading', isLoading);
}

function showError() {
    alert('An error occurred while processing your request. Please try again or check if the backend server is running.');
}

// ============================================
// Reset Handler
// ============================================

resetBtn.addEventListener('click', () => {
    loanForm.reset();
    resultsPlaceholder.style.display = 'block';
    resultsContent.style.display = 'none';
    currentPrediction = null;
    
    // Scroll to form
    loanForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

// ============================================
// Download Report Handler
// ============================================

downloadBtn.addEventListener('click', () => {
    if (!currentPrediction) return;
    
    const { prediction, formData } = currentPrediction;
    const totalIncome = formData.ApplicantIncome + formData.CoapplicantIncome;
    const emi = calculateEMI(formData.LoanAmount, formData.Loan_Amount_Term);
    
    const reportContent = `
LOAN ELIGIBILITY REPORT
========================

Generated: ${new Date().toLocaleString()}

PREDICTION RESULT
-----------------
Status: ${prediction}
Confidence: ${calculateConfidence(prediction, formData).toFixed(1)}%

APPLICANT INFORMATION
---------------------
Gender: ${formData.Gender}
Marital Status: ${formData.Married}
Dependents: ${formData.Dependents}
Education: ${formData.Education}
Employment: ${formData.Self_Employed === 'Yes' ? 'Self-Employed' : 'Salaried'}

FINANCIAL DETAILS
-----------------
Applicant Income: ₹${formData.ApplicantIncome.toLocaleString('en-IN')}
Co-applicant Income: ₹${formData.CoapplicantIncome.toLocaleString('en-IN')}
Total Income: ₹${totalIncome.toLocaleString('en-IN')}
Loan Amount: ₹${formData.LoanAmount.toLocaleString('en-IN')}
Loan Term: ${formData.Loan_Amount_Term} months
Estimated EMI: ₹${emi.toLocaleString('en-IN')}
Credit History: ${formData.Credit_History === 1 ? 'Good' : 'Poor'}
Property Area: ${formData.Property_Area}

KEY METRICS
-----------
Income-to-Loan Ratio: ${(totalIncome / formData.LoanAmount).toFixed(2)}
EMI-to-Income Ratio: ${(emi / totalIncome * 100).toFixed(1)}%

---
Generated by LoanIQ - AI-Powered Loan Eligibility Predictor
    `.trim();
    
    // Create and download file
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LoanIQ_Report_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
});

// ============================================
// Smooth Scrolling for Navigation
// ============================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            
            // Update active nav link
            document.querySelectorAll('.nav-link').forEach(link => {
                link.classList.remove('active');
            });
            this.classList.add('active');
        }
    });
});

// ============================================
// Initialize
// ============================================

console.log('LoanIQ initialized successfully!');
console.log('Backend API URL:', CONFIG.API_URL);
